# theme/theme.py
import streamlit as st

def inject_theme():
    """Inject global CSS + chat widget styling (WhatsApp-like)."""

    st.markdown("""
    <style>

    /* ------------------------------
       GLOBAL PAGE STYLING
    ------------------------------ */

    .main {
        background: linear-gradient(135deg, #0a0e27, #1a1f3a);
        color: #E8EAED;
    }

    /* Remove default Streamlit padding */
    .block-container {
        padding-top: 1rem;
        padding-bottom: 1rem;
        padding-left: 2rem;
        padding-right: 2rem;
    }

    /* ------------------------------
       HEADER BANNER
    ------------------------------ */

    .header-box {
        text-align: center;
        padding: 25px;
        background: linear-gradient(135deg, #8b5cf6, #6366f1);
        border-radius: 12px;
        margin-bottom: 30px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.35);
    }

    .header-title {
        color: white;
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 5px;
    }

    .header-subtitle {
        color: rgba(255,255,255,0.85);
        font-size: 1rem;
    }

    /* ------------------------------
       METRIC BOXES
    ------------------------------ */

    .metric-box {
        background: rgba(139, 92, 246, 0.18);
        border-radius: 8px;
        padding: 15px;
        text-align: center;
        box-shadow: inset 0 0 6px rgba(0,0,0,0.2);
    }

    /* ------------------------------
       AGENT STATUS CARDS
    ------------------------------ */

    .agent-card {
        background: rgba(30, 35, 60, 0.75);
        border-radius: 12px;
        padding: 18px;
        border-left: 4px solid #6366f1;
        margin-bottom: 12px;
        transition: 0.3s ease;
    }

    .agent-card.working {
        border-left-color: #8b5cf6;
        background: rgba(139, 92, 246, 0.2);
        animation: pulse 2s infinite;
    }

    .agent-card.complete {
        border-left-color: #10b981;
        background: rgba(16, 185, 129, 0.2);
    }

    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.75; }
    }

    /* ------------------------------
       CHAT WIDGET
    ------------------------------ */

    #chat-button {
        position: fixed;
        bottom: 25px;
        right: 25px;
        background: #6366f1;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        box-shadow: 0 4px 10px rgba(0,0,0,0.25);
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        transition: 0.2s ease-in-out;
    }

    #chat-button:hover {
        transform: scale(1.08);
        background: #7c80ff;
    }

    #chat-popup {
        position: fixed;
        bottom: 100px;
        right: 25px;
        width: 350px;
        height: 480px;
        background: #1f233e;
        border-radius: 15px;
        box-shadow: 0 6px 16px rgba(0,0,0,0.4);
        padding: 12px;
        display: none;
        flex-direction: column;
        z-index: 9999;
    }

    #chat-header {
        text-align: center;
        background: #6366f1;
        padding: 10px;
        color: white;
        border-radius: 10px;
        font-size: 1rem;
        font-weight: bold;
        margin-bottom: 10px;
    }

    #chat-messages {
        flex: 1;
        overflow-y: auto;
        padding-right: 5px;
    }

    /* Chat bubbles */
    .msg-user {
        background: #4b5563;
        color: white;
        padding: 10px;
        border-radius: 12px;
        margin: 6px 0;
        width: fit-content;
        margin-left: auto;
        max-width: 80%;
    }

    .msg-bot {
        background: #6366f1;
        color: white;
        padding: 10px;
        border-radius: 12px;
        margin: 6px 0;
        width: fit-content;
        margin-right: auto;
        max-width: 80%;
    }

    #chat-input {
        display: flex;
        margin-top: 10px;
    }

    #chat-input-box {
        flex: 1;
        padding: 10px;
        border-radius: 10px;
        border: none;
        outline: none;
        background: #2d3252;
        color: white;
    }

    #chat-send {
        background: #6366f1;
        margin-left: 8px;
        padding: 10px 15px;
        border-radius: 10px;
        cursor: pointer;
        color: white;
        border: none;
    }

    </style>

    <!-- ------------------------------
         CHAT POPUP JS
    ------------------------------ -->

    <script>
    function toggleChat() {
        const popup = document.getElementById("chat-popup");
        popup.style.display = popup.style.display === "flex" ? "none" : "flex";
    }
    </script>
    """, unsafe_allow_html=True)


def header():
    """Render header banner."""
    st.markdown("""
    <div class='header-box'>
        <div class='header-title'>🏦 LoanFlow AI</div>
        <div class='header-subtitle'>5-Agent Intelligent Loan Processing System</div>
    </div>
    """, unsafe_allow_html=True)


def agent_card(name, icon, status, result=""):
    """Render a reusable agent card."""
    status_class = status if status in ["idle", "working", "complete", "error"] else ""
    st.markdown(f"""
    <div class="agent-card {status_class}">
        <div style='display:flex; justify-content:space-between; align-items:center;'>
            <div><span style='font-size:1.5rem'>{icon}</span> <strong>{name}</strong></div>
            <div style='font-size:1.3rem'>{status}</div>
        </div>
        {f"<div style='margin-top:8px; color:#10b981'>{result}</div>" if result else ""}
    </div>
    """, unsafe_allow_html=True)
