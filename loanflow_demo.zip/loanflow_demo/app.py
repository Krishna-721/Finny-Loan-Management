import streamlit as st

from agents.sales_agent import collect_sales_info
from agents.verification_agent import verify_pan
from agents.underwriting_agent import run_underwriting
from agents.document_agent import verify_salary_slip
from agents.sanction_agent import create_sanction_letter

from theme.theme import header

# ------------------------------------
# INIT SESSION
# ------------------------------------
if "flow_step" not in st.session_state:
    st.session_state.flow_step = 1

for key in ["sales_data", "verification_data", "underwriting_data", "document_data", "sanction_data"]:
    if key not in st.session_state:
        st.session_state[key] = None


# ------------------------------------
# STEP 1 — SALES AGENT (Loan Details)
# ------------------------------------
def step_sales():
    st.markdown(header("Step 1: Loan Details"),unsafe_allow_html=True)

    amount = st.number_input("Loan Amount", min_value=10000)
    purpose = st.selectbox("Purpose", ["Education", "Business", "Home", "Personal", "Medical"])
    tenure = st.selectbox("Tenure (months)", [12, 24, 36, 48, 60])

    if st.button("Next → Verification"):
        st.session_state.sales_data = collect_sales_info(amount, purpose, tenure)
        st.session_state.flow_step = 2


# ------------------------------------
# STEP 2 — VERIFICATION AGENT (PAN)
# ------------------------------------
def step_verification():
    st.markdown(header("Step 2: PAN Verification"),unsafe_allow_html=True)

    pan = st.text_input("Enter PAN (ABCDE1234F)")

    if st.button("Verify PAN"):
        details, error = verify_pan(pan)

        if error:
            st.error(error)
        else:
            st.session_state.verification_data = details
            st.session_state.flow_step = 3

            st.success("PAN verified successfully!")
            st.json(details)


# ------------------------------------
# STEP 3 — UNDERWRITING AGENT
# ------------------------------------
def step_underwriting():
    st.markdown(header("Step 3: Underwriting Check"),unsafe_allow_html=True)

    income = st.number_input("Monthly Income", min_value=5000)
    emp_type = st.selectbox("Employment Type", ["Salaried", "Self-Employed", "Business Owner"])

    if st.button("Run Underwriting"):
        sales = st.session_state.sales_data
        verify = st.session_state.verification_data

        # UPDATED underwriting call → now compatible with new interest.py
        result = run_underwriting(
            loan_amount=sales["loan_amount"],
            tenure=sales["loan_tenure"],
            credit_score=verify["credit_score"],
            existing_emi=verify["existing_emi"],
            income=income,
            employment_type=emp_type,
            loan_purpose=sales["loan_purpose"]
        )

        st.session_state.underwriting_data = result

        if result["decision"] == "APPROVED":
            st.success("Loan Approved!")
            st.json(result)
            st.session_state.flow_step = 4
        else:
            st.error("Loan Rejected")
            st.warning(result["reason"])


# ------------------------------------
# STEP 4 — DOCUMENT AGENT
# ------------------------------------
def step_documents():
    st.markdown(header("Step 4: Upload Documents"),unsafe_allow_html=True)

    uploaded = st.file_uploader("Upload Salary Slip (PDF/Image)")

    if st.button("Verify Document"):
        ok, msg = verify_salary_slip(uploaded)

        if not ok:
            st.error(msg)
        else:
            st.success(msg)
            st.session_state.document_data = msg
            st.session_state.flow_step = 5


# ------------------------------------
# STEP 5 — SANCTION AGENT
# ------------------------------------
def step_sanction():
    st.markdown(header("Step 5: Sanction Letter"),unsafe_allow_html=True)

    sales = st.session_state.sales_data
    uw = st.session_state.underwriting_data

    data = {
        "Loan Amount": sales["loan_amount"],
        "Tenure": sales["loan_tenure"],
        "Interest Rate": uw["interest_rate"],
        "EMI": uw["emi"],
        "Decision": uw["decision"]
    }

    if st.button("Generate Sanction Letter"):
        filename = create_sanction_letter(data)
        st.success("Sanction Letter Generated!")

        with open(filename, "rb") as f:
            st.download_button("Download PDF", f, file_name=filename)

        st.session_state.sanction_data = filename
        st.session_state.flow_step = 6


# ------------------------------------
# STEP 6 — COMPLETE
# ------------------------------------
def step_complete():
    st.success("Loan Processing Completed 🎉")
    st.markdown("Thank you for using LoanFlow AI!")


# ------------------------------------
# STEP ROUTER (Controller)
# ------------------------------------
step_map = {
    1: step_sales,
    2: step_verification,
    3: step_underwriting,
    4: step_documents,
    5: step_sanction,
    6: step_complete
}

step_map[st.session_state.flow_step]()
