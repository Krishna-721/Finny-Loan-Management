from core.pdf_generator import generate_sanction_letter

def create_sanction_letter(data):
    return generate_sanction_letter(data)
