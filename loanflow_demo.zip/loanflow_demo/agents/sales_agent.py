def collect_sales_info(amount, purpose, tenure):
    return {
        "loan_amount": amount,
        "loan_purpose": purpose,
        "loan_tenure": tenure
    }
